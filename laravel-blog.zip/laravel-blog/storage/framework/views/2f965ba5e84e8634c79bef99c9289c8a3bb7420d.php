<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-6">
            <img src="<?php echo e(asset('/img')); ?>/<?php echo e($blog->thumbnail); ?>" class="img-fluid" alt="...">
        </div>
        <div class="col-lg-6">
            <h3 class="mt-4"> <?php echo e($blog->title); ?> </h3>
            <h5 class="mt-3"><?php echo e($blog->excerpt); ?></h5>
            <p class="mt-4"><?php echo e($blog->content); ?></p>
            <p class="mt-4"><strong><?php echo e($blog->status); ?></strong></p>
            <p class="text-muted"><?php echo e($blog->author); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/juneds/Project/laravel-project/laravel-blog/resources/views/blog/show.blade.php ENDPATH**/ ?>