<?php $__env->startSection('content'); ?>
<!-- Card -->
<div class="container mt-5">
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card">
                <a href="<?php echo e($blog->id); ?>">
                    <img src="<?php echo e(asset('/img')); ?>/<?php echo e($blog->thumbnail); ?>" class="card-img-top">
                </a>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($blog->title); ?></h5>
                    <p class="card-text"><?php echo e($blog->excerpt); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- End Card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/juneds/Project/laravel-project/laravel-blog/resources/views/blog/index.blade.php ENDPATH**/ ?>