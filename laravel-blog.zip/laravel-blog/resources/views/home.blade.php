@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <a href="/home/create" class="btn btn-primary mb-3">Buat Artikel</a>

            @if(session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
            @endif

            <ul class="list-group">
                @foreach($blogs as $blog)
                <li class="list-group-item">{{ $blog->title }}
                    <form action="/home/{{ $blog->id }}" method="post" class="d-inline">
                        @method('delete')
                        @csrf
                        <button class="btn badge badge-danger float-right text-light">Delete</button>
                    </form>
                    <a href="/home/{{ $blog->id }}" class="badge badge-success float-right text-light mr-1">Edit</a>
                </li>
                @endforeach
            </ul>

        </div>
    </div>
</div>
</div>
@endsection