@extends('layout.main')

@section('content')
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-6">
            <img src="{{ asset('/img') }}/{{ $blog->thumbnail }}" class="img-fluid" alt="...">
        </div>
        <div class="col-lg-6">
            <h3 class="mt-4"> {{ $blog->title }} </h3>
            <h5 class="mt-3">{{ $blog->excerpt }}</h5>
            <p class="mt-4">{{ $blog->content }}</p>
            <p class="mt-4"><strong>{{ $blog->status }}</strong></p>
            <p class="text-muted">{{ $blog->author }}</p>
        </div>
    </div>
</div>
@endsection