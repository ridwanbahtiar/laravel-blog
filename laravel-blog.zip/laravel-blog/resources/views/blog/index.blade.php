@extends('layout.main')

@section('content')
<!-- Card -->
<div class="container mt-5">
    <div class="row row-cols-1 row-cols-md-3 g-4">
        @foreach($blogs as $blog)
        <div class="col">
            <div class="card">
                <a href="{{ $blog->id }}">
                    <img src="{{ asset('/img') }}/{{ $blog->thumbnail }}" class="card-img-top">
                </a>
                <div class="card-body">
                    <h5 class="card-title">{{ $blog->title }}</h5>
                    <p class="card-text">{{ $blog->excerpt }}</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
<!-- End Card -->
@endsection()